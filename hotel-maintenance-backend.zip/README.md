# Hotel Maintenance & Inventory — Backend (Google Apps Script)

Backend สำหรับหน้าเว็บ LIFF "Hotel Engineering System" — เขียนให้ตรงกับ API contract
ที่ `index.html` เรียกใช้จริง (`fetch(API_URL, {method:'POST', body: JSON.stringify({action, data})})`)

**Google Sheet ที่ผูกกับโปรเจกต์นี้:** `Hotel_Maintenance_System_v4.xlsx` (อัปโหลดเป็น Google Sheets แล้วเปิด
Extensions > Apps Script เพื่อวางไฟล์ .gs ทั้งหมดในนี้เข้าไป — โปรเจกต์นี้ต้อง "bound" กับชีตนั้นเสมอ
เพราะทุกฟังก์ชันเรียก `SpreadsheetApp.getActiveSpreadsheet()`)

## โครงสร้างไฟล์

| ไฟล์ | หน้าที่ |
|---|---|
| `Code.gs` | จุดเข้า `doPost`/`doGet` — route ตาม `action` ไปยังฟังก์ชันที่ถูกต้อง |
| `Config.gs` | ค่าคงที่: ชื่อชีต, ตำแหน่งคอลัมน์, สถานะ, role, permission key |
| `Utils.gs` | ฟังก์ชันช่วยอ่าน/เขียนชีตทั่วไป |
| `Auth.gs` | ผูก LINE user กับ Users sheet + สร้าง permissions map |
| `Tickets.gs` | สร้าง/แก้ไข/ปิด/เปิดใหม่ ใบแจ้งซ่อม |
| `Inventory.gs` | อ่านสต๊อก |
| `StockMovements.gs` | Stock In / Stock Out (แหล่งเดียวที่แก้ยอดคงเหลือได้) |
| `Requisitions.gs` | คำขออะไหล่ (Pending Parts) ผูกกับใบแจ้งซ่อม |
| `PdfExport.gs` | ออก PDF จากชีต `Ticket_Print` แล้วเซฟลง Drive |
| `Staff.gs` | จัดการพนักงาน (role/status) |
| `AppSettings.gs` | ค่าตั้งค่าทั่วไป (เช่นรายชื่อแผนก) แบบ key/value |
| `Triggers.gs` | เมนูในชีต + trigger เช็คของใกล้หมดสต๊อกรายวัน |

## Action ↔ ฟังก์ชัน (ตรงกับที่หน้าเว็บเรียก)

| action (จาก index.html) | ฟังก์ชันที่รัน | ต้องมีสิทธิ์ |
|---|---|---|
| `getUser` | `apiGetUser_` | — |
| `registerUser` | `apiRegisterUser_` | — |
| `getInitialData` | `apiGetInitialData_` | — (แต่ละ list ข้างในกรองตาม permission) |
| `createTicket` | `apiCreateTicket_` | ต้องเป็น user ACTIVE เท่านั้น (ไม่ gate เพิ่ม) |
| `updateTicketStatus` | `apiUpdateTicketStatus_` | `CHANGE_STATUS` |
| `closeTicket` | `apiCloseTicket_` | `CLOSE_TICKET` |
| `reopenTicket` | `apiReopenTicket_` | `REOPEN_TICKET` |
| `createPendingPartsPDF` | `apiCreatePendingPartsPdf_` | `PRINT_PENDING_PARTS_PDF` |
| `stockIn` / `stockOut` | `apiStockIn_` / `apiStockOut_` | `VIEW_STOCK` |
| `updateStaff` | `apiUpdateStaff_` | `VIEW_STAFF` |
| `updateSetting` | `apiUpdateSetting_` | `VIEW_SETTINGS` |

Role `ADMIN` ผ่านทุก permission โดยอัตโนมัติ (ตรงกับ `isAdmin()` ฝั่งหน้าเว็บ)

## ค่าคงที่ที่ต้องตรงกันเป๊ะๆ ระหว่างหน้าเว็บกับ backend

ถ้าจะเพิ่ม/แก้ status, priority, category, department, permission key ใดๆ **ต้องแก้ 3 จุดพร้อมกัน**:
1. `Config.gs` (ค่าคงที่ฝั่ง backend)
2. `<select>` options ใน `index.html`
3. ชีต `Settings` (dropdown list) ในไฟล์ Excel/Google Sheets

## วิธี Deploy

1. **สร้าง Google Sheet จริงจากไฟล์ Excel** — อัปโหลด `Hotel_Maintenance_System_v4.xlsx` เข้า Google Drive
   แล้วเปิดเป็น Google Sheets (File > Save as Google Sheets)
2. เปิด **Extensions > Apps Script** จากชีตนั้น แล้ววางไฟล์ `.gs` ทั้งหมดในโฟลเดอร์ `src/` เข้าไป
   (หรือใช้ `clasp push` — ดูหัวข้อถัดไป)
3. ไปที่ **Project Settings > Script Properties** เพิ่ม:
   - `PDF_OUTPUT_FOLDER_ID` = Google Drive Folder ID ที่จะเก็บไฟล์ PDF ที่ export
   - (ออปชัน) `LINE_CHANNEL_ACCESS_TOKEN` = ถ้าต้องการให้ระบบ push แจ้งเตือนของใกล้หมดเข้า LINE
4. **Deploy > New deployment > Web app**
   - Execute as: `Me`
   - Who has access: `Anyone` (หรือ `Anyone with Google account` ตามนโยบายองค์กร)
5. คัดลอก URL ที่ได้ ไปแทนที่ค่า `API_URL` ในไฟล์ `index.html` ของหน้าเว็บ LIFF
6. Host `index.html` ที่ไหนก็ได้ที่เป็น HTTPS (GitHub Pages, Firebase Hosting ฯลฯ) แล้วนำ URL
   ไปตั้งเป็น Endpoint URL ของ LIFF app ใน [LINE Developers Console](https://developers.line.biz/console/)
   (LIFF ID ที่ฝังไว้ในโค้ดคือ `2010924055-ptu13GAx` — ต้องเป็น LIFF app ที่คุณเป็นเจ้าของเท่านั้น)
7. รันฟังก์ชัน `setupDailyLowStockTrigger` ครั้งเดียวจาก Apps Script editor (หรือกดจากเมนู "ระบบแจ้งซ่อม"
   ในหน้าชีต) เพื่อตั้ง trigger เช็คของใกล้หมดสต๊อกทุกเช้า 08:00

## Deploy ผ่าน clasp (แนะนำ — เพื่อ push ขึ้น GitHub ได้)

```bash
npm install -g @google/clasp
clasp login
# สร้างโปรเจกต์ Apps Script ใหม่ที่ผูกกับชีต (ต้องมี Google Sheet ID อยู่แล้ว)
clasp create --type sheets --parentId <GOOGLE_SHEET_ID> --rootDir ./src
clasp push
```

จากนั้น `git init`, `git remote add origin <your-github-repo-url>`, `git push` ได้ตามปกติ —
ไฟล์ `.clasp.json` เก็บ Script ID ไว้ (ห้าม commit ถ้า repo เป็น public เพราะเป็นตัวชี้ไปยังโปรเจกต์จริง
ดู `.gitignore` ที่แนบมาให้)

## ข้อจำกัด/สิ่งที่ยังไม่ได้ทำ (บอกไว้ตรงๆ)

- **รูปภาพประกอบการแจ้งซ่อม**: ในโค้ด `index.html` ปัจจุบัน ผู้ใช้ถ่าย/เลือกรูปได้แต่ **ยังไม่ได้ส่งรูปไปที่ backend จริง**
  (`createTicket` ที่ยิงไป server ไม่มี field รูปภาพแนบไปด้วย) — คอลัมน์ `image_urls` ในชีต Tickets เตรียมไว้รองรับแล้ว
  แต่ต้องแก้ `repairForm` submit handler ในหน้าเว็บให้ upload รูปเข้า Google Drive (ผ่าน action ใหม่ เช่น `uploadImage`)
  แล้วส่ง URL กลับมาแนบกับ `createTicket` ก่อน ถึงจะใช้งานได้จริง
- **การอนุมัติผู้ใช้ใหม่**: ตอนนี้ `registerUser_` ตั้ง `status: ACTIVE` ทันที (ทุกคนลงทะเบียนแล้วใช้งานได้เลย)
  ถ้าต้องการให้แอดมินกดอนุมัติก่อน ต้องเปลี่ยนเป็น `status: PENDING` แล้วเพิ่ม action `approveUser` + ปรับ
  `apiGetUser_` ให้คืน status ที่หน้าเว็บรู้จัก (ตอนนี้หน้าเว็บรองรับแค่ `APPROVED` กับ `NOT_REGISTERED`
  สถานะอื่นจะ error ทันที — ต้องแก้ `checkUserAuth()` ในหน้าเว็บด้วยถ้าจะเพิ่ม flow นี้)
- **รายการอะไหล่ใน Pending Parts**: ตอนนี้ `updateTicketStatus` ที่เปลี่ยนเป็น `PENDING_PARTS` จะสร้าง
  requisition แบบ "เปล่า" (ไม่มีรายการสินค้า) ให้อัตโนมัติ เพราะหน้าเว็บยังไม่มีฟอร์มให้เลือกอะไหล่ตอนกดปุ่มนี้
  ต้องไปเพิ่มรายการเองในชีต `Requisition_Items` หรือเพิ่มฟอร์มในหน้าเว็บ + action ใหม่ (เช่น `addRequisitionItem`)
