/**
 * Requisitions.gs
 * "Pending Parts" — คำขออะไหล่ผูกกับใบแจ้งซ่อม 1 ใบ (ไม่ใช่ใบสั่งซื้อผู้จำหน่ายทั่วไป)
 * สร้างอัตโนมัติเมื่อช่างเปลี่ยนสถานะ ticket เป็น PENDING_PARTS (ดู ApiRouter.gs)
 */

function createRequisitionForTicket_(lineUserId, ticketNo, items, note) {
  const user = getUserByLineId_(lineUserId);
  const ticket = getTicketByNo_(ticketNo);
  if (!ticket) throw new Error('ไม่พบใบแจ้งซ่อม: ' + ticketNo);

  const reqNo = generateId_('REQ', true);
  appendRowFromObject_(SHEETS.REQUISITIONS, COLS.REQUISITIONS, {
    requisition_no: reqNo,
    ticket_no: ticketNo,
    location: ticket.location,
    department: ticket.department,
    submitted_by: user ? user.full_name : '',
    status: 'PENDING',
    note: note || '',
    created_at: nowTs_(),
  });

  (items || []).forEach(function (it) {
    appendRowFromObject_(SHEETS.REQUISITION_ITEMS, COLS.REQUISITION_ITEMS, {
      requisition_no: reqNo,
      item_code: it.item_code,
      quantity_requested: it.quantity,
      unit_price: it.unit_price || 0,
    });
  });

  return reqNo;
}

/** รายการ requisition ทั้งหมด ตรงกับ renderRequisitions() ในหน้าเว็บ */
function listRequisitions_() {
  const sh = sheet_(SHEETS.REQUISITIONS);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return [];
  const data = sh.getRange(2, 1, lastRow - 1, 12).getValues();
  return data
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      const o = {};
      Object.keys(COLS.REQUISITIONS).forEach(function (key) { o[key] = r[COLS.REQUISITIONS[key] - 1]; });
      return o;
    })
    .reverse();
}

function findRequisitionForTicket_(ticketNo) {
  const all = listRequisitions_();
  return all.find(function (r) { return r.ticket_no === ticketNo; }) || null;
}
