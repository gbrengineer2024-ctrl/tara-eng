/**
 * PdfExport.gs
 * action: createPendingPartsPDF — ออก PDF ใบขออะไหล่ (ใช้เทมเพลตชีต Ticket_Print)
 * แล้วบันทึกลิงก์กลับไปที่ Requisitions.pdf_url และ Tickets.pdf_url
 */

function exportSheetAsPdf_(sheetName, inputCellA1, inputValue, fileNamePrefix) {
  const ss = ss_();
  const sh = sheet_(sheetName);

  sh.getRange(inputCellA1).setValue(inputValue);
  SpreadsheetApp.flush();

  const gid = sh.getSheetId();
  const url = 'https://docs.google.com/spreadsheets/d/' + ss.getId() + '/export'
    + '?format=pdf&gid=' + gid + '&portrait=true&fitw=true&gridlines=false&printtitle=false&sheetnames=false';

  const response = UrlFetchApp.fetch(url, {
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true,
  });
  if (response.getResponseCode() !== 200) {
    throw new Error('Export PDF ล้มเหลว: ' + response.getContentText());
  }

  const folder = DriveApp.getFolderById(getProp_('PDF_OUTPUT_FOLDER_ID'));
  const fileName = fileNamePrefix + '_' + inputValue + '_' + Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyyMMdd_HHmmss') + '.pdf';
  const file = folder.createFile(response.getBlob().setName(fileName));
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return file.getUrl();
}

/** action: createPendingPartsPDF */
function createPendingPartsPdf_(lineUserId, ticketNo) {
  requirePermission_(lineUserId, 'PRINT_PENDING_PARTS_PDF');

  const pdfUrl = exportSheetAsPdf_(SHEETS.TICKET_PRINT, 'F4', ticketNo, 'PendingParts');

  const ticketRow = findRowByValue_(SHEETS.TICKETS, COLS.TICKETS.ticket_no, ticketNo);
  if (ticketRow !== -1) updateRowFields_(SHEETS.TICKETS, ticketRow, COLS.TICKETS, { pdf_url: pdfUrl });

  const req = findRequisitionForTicket_(ticketNo);
  if (req) {
    const reqRow = findRowByValue_(SHEETS.REQUISITIONS, COLS.REQUISITIONS.requisition_no, req.requisition_no);
    if (reqRow !== -1) updateRowFields_(SHEETS.REQUISITIONS, reqRow, COLS.REQUISITIONS, { pdf_url: pdfUrl });
  }

  return pdfUrl;
}
