/**
 * Triggers.gs
 * เมนูใช้งานจากหน้า Google Sheets โดยตรง + trigger รายวันเช็คของใกล้หมด
 *
 * การแจ้งเตือนผ่าน LINE เป็นออปชัน — ถ้าไม่ได้ตั้งค่า Script Property
 * LINE_CHANNEL_ACCESS_TOKEN ไว้ ระบบจะข้ามการส่งแจ้งเตือนไปเงียบๆ (ไม่ error)
 * เพราะระบบหลักตอนนี้คุยกับผู้ใช้ผ่านหน้าเว็บ LIFF ไม่ใช่ chatbot แล้ว
 */

function setupDailyLowStockTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'dailyLowStockCheck') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('dailyLowStockCheck')
    .timeBased().everyDays(1).atHour(8).inTimezone('Asia/Bangkok').create();
}

function dailyLowStockCheck() {
  const items = getLowStockItems_();
  if (items.length === 0) return;
  const lines = items.map(function (i) {
    return '- ' + i.item_name + ' (' + i.item_code + ') เหลือ ' + i.stock + '/' + i.min_stock;
  });
  Logger.log('LOW STOCK:\n' + lines.join('\n'));
  pushLineMessageToRole_('SUPERVISOR', 'รายการอะไหล่ใกล้หมดสต๊อกวันนี้:\n' + lines.join('\n'));
  pushLineMessageToRole_('ADMIN', 'รายการอะไหล่ใกล้หมดสต๊อกวันนี้:\n' + lines.join('\n'));
}

/** ยิงข้อความ push หา user ทุกคนที่มี role ที่กำหนด — ข้ามเงียบๆ ถ้ายังไม่ตั้งค่า LINE token */
function pushLineMessageToRole_(role, text) {
  const token = PropertiesService.getScriptProperties().getProperty('LINE_CHANNEL_ACCESS_TOKEN');
  if (!token) return;

  const staff = listStaff_().filter(function (u) { return u.role === role && u.status === 'ACTIVE'; });
  staff.forEach(function (u) {
    UrlFetchApp.fetch('https://api.line.me/v2/bot/message/push', {
      method: 'post',
      contentType: 'application/json',
      headers: { Authorization: 'Bearer ' + token },
      payload: JSON.stringify({ to: u.line_user_id, messages: [{ type: 'text', text: text }] }),
      muteHttpExceptions: true,
    });
  });
}

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('ระบบแจ้งซ่อม')
    .addItem('ออก PDF ใบงานที่กรอกใน Ticket_Print!F4', 'menuExportSelectedTicketPdf_')
    .addItem('เช็คของใกล้หมดสต๊อกตอนนี้', 'dailyLowStockCheck')
    .addItem('ตั้งค่า Trigger เช็คของใกล้หมดทุกวัน', 'setupDailyLowStockTrigger')
    .addToUi();
}

function menuExportSelectedTicketPdf_() {
  const ticketNo = sheet_(SHEETS.TICKET_PRINT).getRange('F4').getValue();
  if (!ticketNo) {
    SpreadsheetApp.getUi().alert('กรุณากรอกเลขที่ ticket_no ในช่อง F4 ของชีต Ticket_Print ก่อน');
    return;
  }
  const url = exportSheetAsPdf_(SHEETS.TICKET_PRINT, 'F4', ticketNo, 'JobReport');
  SpreadsheetApp.getUi().alert('ออก PDF สำเร็จ: ' + url);
}
