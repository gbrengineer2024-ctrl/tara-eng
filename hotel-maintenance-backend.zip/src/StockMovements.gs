/**
 * StockMovements.gs
 * จุดเดียวที่แก้ Inventory.quantity ได้ — ตรงกับปุ่ม "Stock In / Stock Out" ในหน้าเว็บ (openStockMove/saveStockMove)
 */

/**
 * @param {Object} p {itemCode, movementType, quantity, note, performedBy}
 *   quantity ที่ส่งเข้ามาเป็นค่าบวกเสมอ (ผู้ใช้กรอกจำนวน) ฟังก์ชันนี้จะกำหนดเครื่องหมายเองตาม movementType
 */
function recordMovement_(p) {
  return withLock_(function () {
    const invRow = findRowByValue_(SHEETS.INVENTORY, COLS.INVENTORY.item_code, p.itemCode);
    if (invRow === -1) throw new Error('ไม่พบรหัสสินค้าในสต๊อก: ' + p.itemCode);

    const signedQty = (p.movementType === MOVEMENT_TYPE.STOCK_OUT || p.movementType === MOVEMENT_TYPE.ADJUST_OUT)
      ? -Math.abs(p.quantity)
      : Math.abs(p.quantity);

    const invSheet = sheet_(SHEETS.INVENTORY);
    const currentQty = invSheet.getRange(invRow, COLS.INVENTORY.quantity).getValue() || 0;
    const newQty = currentQty + signedQty;
    if (newQty < 0) {
      throw new Error('สต๊อกไม่พอ: ' + p.itemCode + ' คงเหลือ ' + currentQty + ' แต่ขอเบิก ' + Math.abs(signedQty));
    }

    invSheet.getRange(invRow, COLS.INVENTORY.quantity).setValue(newQty);
    invSheet.getRange(invRow, COLS.INVENTORY.updated_at).setValue(nowTs_());
    if (p.performedBy) invSheet.getRange(invRow, COLS.INVENTORY.updated_by).setValue(p.performedBy);
    // หมายเหตุ: คอลัมน์ 'status' (LOW/OK) เป็นสูตรในชีตอยู่แล้ว จะอัปเดตอัตโนมัติ ไม่ต้องเขียนโค้ดเพิ่ม

    appendRowFromObject_(SHEETS.STOCK_MOVEMENTS, COLS.STOCK_MOVEMENTS, {
      movement_id: generateId_('MV'),
      movement_date: nowTs_(),
      item_code: p.itemCode,
      movement_type: p.movementType,
      quantity: signedQty,
      ref_type: p.refType || 'MANUAL',
      ref_no: p.refNo || '',
      note: p.note || '',
      performed_by: p.performedBy || '',
      balance_after: newQty,
    });

    return newQty;
  });
}

/** action: stockIn */
function stockIn_(lineUserId, itemCode, quantity, note) {
  const user = requirePermission_(lineUserId, 'VIEW_STOCK');
  return recordMovement_({
    itemCode: itemCode, movementType: MOVEMENT_TYPE.STOCK_IN, quantity: quantity,
    note: note, performedBy: user.full_name,
  });
}

/** action: stockOut */
function stockOut_(lineUserId, itemCode, quantity, note) {
  const user = requirePermission_(lineUserId, 'VIEW_STOCK');
  return recordMovement_({
    itemCode: itemCode, movementType: MOVEMENT_TYPE.STOCK_OUT, quantity: quantity,
    note: note, performedBy: user.full_name,
  });
}
