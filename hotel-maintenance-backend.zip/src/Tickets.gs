/**
 * Tickets.gs
 * ทุกฟังก์ชันในไฟล์นี้คืนค่า/รับพารามิเตอร์ตามที่หน้าเว็บ LIFF ใช้ตรงๆ
 * (ดู index.html: createTicket, updateTicketStatus, closeTicket, reopenTicket)
 */

/** สร้างใบแจ้งซ่อมใหม่ — ทุกคนที่ล็อกอินสร้างได้ ไม่ gate ด้วย permission (ตรงกับพฤติกรรมหน้าเว็บ) */
function createTicket_(lineUserId, data) {
  const user = getUserByLineId_(lineUserId);
  if (!user) throw new Error('ไม่พบผู้ใช้นี้ในระบบ กรุณาลงทะเบียนก่อน');
  if (user.status !== 'ACTIVE') throw new Error('บัญชีผู้ใช้นี้ถูกระงับการใช้งาน');

  const ticketNo = generateId_('REP');
  return withLock_(function () {
    appendRowFromObject_(SHEETS.TICKETS, COLS.TICKETS, {
      ticket_no: ticketNo,
      location: data.location || data.locationName || '',
      category: data.category,
      priority: data.priority || 'NORMAL',
      issue: data.issue,
      status: TICKET_STATUS.NEW,
      reporter: user.full_name,
      department: user.department,
      created_at: nowTs_(),
      reporter_line_id: lineUserId,
    });
    return ticketNo;
  });
}

/** เปลี่ยนสถานะทั่วไป (รับงาน/พักงาน/รออะไหล่/ทำต่อ ฯลฯ) — ต้องมีสิทธิ์ CHANGE_STATUS */
function updateTicketStatus_(lineUserId, ticketNo, newStatus, note) {
  const user = requirePermission_(lineUserId, 'CHANGE_STATUS');
  const row = findRowByValue_(SHEETS.TICKETS, COLS.TICKETS.ticket_no, ticketNo);
  if (row === -1) throw new Error('ไม่พบใบแจ้งซ่อม: ' + ticketNo);

  const fields = { status: newStatus, updated_at: nowTs_() };
  if (note) fields.work_note = note;
  // คนแรกที่กด "รับงาน" (NEW -> IN_PROGRESS) จะถูกบันทึกเป็นช่างผู้รับผิดชอบอัตโนมัติ
  const current = readRowAsObject_(SHEETS.TICKETS, row, COLS.TICKETS);
  if (current.status === TICKET_STATUS.NEW && newStatus === TICKET_STATUS.IN_PROGRESS && !current.technician) {
    fields.technician = user.full_name;
    fields.technician_line_id = lineUserId;
  }
  updateRowFields_(SHEETS.TICKETS, row, COLS.TICKETS, fields);
}

/** ปิดงาน — ต้องมีสิทธิ์ CLOSE_TICKET */
function closeTicket_(lineUserId, ticketNo, notes) {
  requirePermission_(lineUserId, 'CLOSE_TICKET');
  const row = findRowByValue_(SHEETS.TICKETS, COLS.TICKETS.ticket_no, ticketNo);
  if (row === -1) throw new Error('ไม่พบใบแจ้งซ่อม: ' + ticketNo);
  updateRowFields_(SHEETS.TICKETS, row, COLS.TICKETS, {
    status: TICKET_STATUS.COMPLETED,
    completed_at: nowTs_(),
    updated_at: nowTs_(),
    work_note: notes || '',
  });
}

/** เปิดงานที่ปิด/ยกเลิกแล้วกลับมาใหม่ — ต้องมีสิทธิ์ REOPEN_TICKET */
function reopenTicket_(lineUserId, ticketNo) {
  requirePermission_(lineUserId, 'REOPEN_TICKET');
  const row = findRowByValue_(SHEETS.TICKETS, COLS.TICKETS.ticket_no, ticketNo);
  if (row === -1) throw new Error('ไม่พบใบแจ้งซ่อม: ' + ticketNo);
  updateRowFields_(SHEETS.TICKETS, row, COLS.TICKETS, {
    status: TICKET_STATUS.REOPENED,
    completed_at: '',
    updated_at: nowTs_(),
  });
}

function getTicketByNo_(ticketNo) {
  const row = findRowByValue_(SHEETS.TICKETS, COLS.TICKETS.ticket_no, ticketNo);
  if (row === -1) return null;
  return readRowAsObject_(SHEETS.TICKETS, row, COLS.TICKETS);
}

/** รายการ ticket ทั้งหมด เรียงล่าสุดก่อน + สรุปจำนวนแยกตามสถานะ (สำหรับ getInitialData) */
function listTicketsWithSummary_() {
  const sh = sheet_(SHEETS.TICKETS);
  const lastRow = sh.getLastRow();
  const summary = { NEW: 0, IN_PROGRESS: 0, ON_HOLD: 0, PENDING_PARTS: 0, COMPLETED: 0, REOPENED: 0, CANCELLED: 0 };
  if (lastRow < 2) return { tickets: [], summary: summary };

  const data = sh.getRange(2, 1, lastRow - 1, 17).getValues();
  const tickets = data
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      const o = {};
      Object.keys(COLS.TICKETS).forEach(function (key) { o[key] = r[COLS.TICKETS[key] - 1]; });
      if (summary[o.status] !== undefined) summary[o.status]++;
      return o;
    })
    .reverse(); // ล่าสุดก่อน

  return { tickets: tickets, summary: summary };
}
