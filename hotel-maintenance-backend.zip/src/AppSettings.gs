/**
 * AppSettings.gs
 * action: updateSetting — ตรงกับ editSetting()/saveSetting()/saveDepartments() ในหน้าเว็บ
 * เก็บเป็น key/value ในชีต AppSettings (แยกจากชีต Settings ที่ใช้แค่ทำ dropdown validation ภายใน Excel เอง)
 */

function getAllAppSettings_() {
  const sh = sheet_(SHEETS.APP_SETTINGS);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return {};
  const data = sh.getRange(2, 1, lastRow - 1, 2).getValues(); // key, value
  const result = {};
  data.forEach(function (r) {
    if (!r[0]) return;
    let v = r[1];
    // ถ้า parse เป็น JSON ได้ (เช่น DEPARTMENTS_JSON เป็น array) ให้คืนเป็น object/array เลย
    try { v = JSON.parse(v); } catch (e) { /* เก็บเป็น string ธรรมดา */ }
    result[r[0]] = v;
  });
  return result;
}

/** action: updateSetting — ต้องมีสิทธิ์ VIEW_SETTINGS */
function updateAppSetting_(lineUserId, key, value) {
  const user = requirePermission_(lineUserId, 'VIEW_SETTINGS');
  const storedValue = typeof value === 'object' ? JSON.stringify(value) : String(value);

  const row = findRowByValue_(SHEETS.APP_SETTINGS, COLS.APP_SETTINGS.key, key);
  if (row === -1) {
    appendRowFromObject_(SHEETS.APP_SETTINGS, COLS.APP_SETTINGS, {
      key: key, value: storedValue, updated_by: user.full_name, updated_at: nowTs_(),
    });
  } else {
    updateRowFields_(SHEETS.APP_SETTINGS, row, COLS.APP_SETTINGS, {
      value: storedValue, updated_by: user.full_name, updated_at: nowTs_(),
    });
  }
}
