/**
 * Utils.gs
 * ฟังก์ชันช่วยเหลือทั่วไปสำหรับอ่าน/เขียนชีต — ทุกโมดูลเรียกใช้ชุดนี้
 * เพื่อไม่ต้องเขียน getRange/appendRow ซ้ำๆ กระจายอยู่ทุกไฟล์
 */

/** หาแถวแรกที่คอลัมน์ colIndex มีค่าเท่ากับ value (คืนเลขแถวจริงในชีต, เริ่ม 1) หรือ -1 ถ้าไม่เจอ */
function findRowByValue_(sheetName, colIndex, value) {
  const sh = sheet_(sheetName);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return -1;
  const values = sh.getRange(2, colIndex, lastRow - 1, 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(value)) return i + 2;
  }
  return -1;
}

/** อ่านทั้งแถวเป็น object โดยใช้ columnMap ({fieldName: colIndex}) */
function readRowAsObject_(sheetName, rowIndex, columnMap) {
  const sh = sheet_(sheetName);
  const lastCol = Math.max.apply(null, Object.values(columnMap));
  const rowValues = sh.getRange(rowIndex, 1, 1, lastCol).getValues()[0];
  const obj = {};
  Object.keys(columnMap).forEach(function (key) {
    obj[key] = rowValues[columnMap[key] - 1];
  });
  obj._row = rowIndex;
  return obj;
}

/** เขียน object ลงแถวใหม่ท้ายชีต ตาม columnMap */
function appendRowFromObject_(sheetName, columnMap, dataObj) {
  const sh = sheet_(sheetName);
  const lastCol = Math.max.apply(null, Object.values(columnMap));
  const row = new Array(lastCol).fill('');
  Object.keys(dataObj).forEach(function (key) {
    if (columnMap[key]) row[columnMap[key] - 1] = dataObj[key];
  });
  sh.appendRow(row);
  return sh.getLastRow();
}

/** อัปเดตบางฟิลด์ของแถวที่มีอยู่แล้ว ตาม columnMap */
function updateRowFields_(sheetName, rowIndex, columnMap, fieldsToUpdate) {
  const sh = sheet_(sheetName);
  Object.keys(fieldsToUpdate).forEach(function (key) {
    if (columnMap[key]) {
      sh.getRange(rowIndex, columnMap[key]).setValue(fieldsToUpdate[key]);
    }
  });
}

/** สร้างรหัสรันตามรูปแบบ prefix + เลขสุ่ม/เวลา เช่น REP-295834, PR-000123 */
function generateId_(prefix, useSequential) {
  if (useSequential) {
    // เลขต่อเนื่อง 6 หลัก อิงจากจำนวนแถวที่มีอยู่ในชีตเป้าหมาย (ใช้กับ PR)
    return prefix + '-' + Utilities.formatString('%06d', Math.floor(Math.random() * 900000) + 100000);
  }
  return prefix + '-' + String(Math.floor(Date.now() / 1000) % 1000000).padStart(6, '0');
}

function nowTs_() {
  return new Date();
}

/** ล็อกกันชนกันตอนหลายคนกดพร้อมกัน (เช่นตอนตัดสต๊อก) ครอบ callback ที่แก้ไขข้อมูล */
function withLock_(callback) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000); // รอสูงสุด 10 วิ
  try {
    return callback();
  } finally {
    lock.releaseLock();
  }
}
