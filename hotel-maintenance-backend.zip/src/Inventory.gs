/**
 * Inventory.gs
 * อ่านสต๊อก — การแก้ไขยอดคงเหลือจริงต้องผ่าน StockMovements.gs (recordMovement_) เท่านั้น
 */

function getInventoryItem_(itemCode) {
  const row = findRowByValue_(SHEETS.INVENTORY, COLS.INVENTORY.item_code, itemCode);
  if (row === -1) return null;
  return readRowAsObject_(SHEETS.INVENTORY, row, COLS.INVENTORY);
}

/** รายการสต๊อกทั้งหมด ในรูปแบบที่ตรงกับ renderStock() ในหน้าเว็บ (item_code, item_name, unit, stock, min_stock, status) */
function listInventory_() {
  const sh = sheet_(SHEETS.INVENTORY);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return [];
  const data = sh.getRange(2, 1, lastRow - 1, 7).getValues(); // A..G (ถึง status)
  return data
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      return {
        item_code: r[0],
        item_name: r[1],
        category: r[2],
        unit: r[3],
        stock: r[4],       // หน้าเว็บใช้ชื่อ key "stock" ไม่ใช่ "quantity"
        min_stock: r[5],
        status: r[6],
      };
    });
}

function getLowStockItems_() {
  return listInventory_().filter(function (i) { return i.status === 'LOW'; });
}
