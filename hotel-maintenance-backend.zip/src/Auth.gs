/**
 * Auth.gs
 * ผูก line_user_id (จาก LIFF getProfile) กับผู้ใช้ในชีต Users
 * และสร้าง permissions map ที่ตรงกับ hasPermission(key) ในหน้าเว็บ LIFF เป๊ะๆ
 */

function getUserByLineId_(lineUserId) {
  const row = findRowByValue_(SHEETS.USERS, COLS.USERS.line_user_id, lineUserId);
  if (row === -1) return null;
  return readRowAsObject_(SHEETS.USERS, row, COLS.USERS);
}

/** ลงทะเบียนผู้ใช้ใหม่ — role เริ่มต้นเป็น REPORTER เสมอ (แอดมินไปเลื่อนสิทธิ์ทีหลังผ่านหน้า Staff Management) */
function registerUser_(lineUserId, empId, fullName, department) {
  const existing = getUserByLineId_(lineUserId);
  if (existing) return existing;
  appendRowFromObject_(SHEETS.USERS, COLS.USERS, {
    line_user_id: lineUserId,
    emp_id: empId,
    full_name: fullName,
    department: department,
    role: DEFAULT_ROLE,
    registered_at: nowTs_(),
    status: 'ACTIVE',
  });
  return getUserByLineId_(lineUserId);
}

/**
 * คืน object { CHANGE_STATUS: true/false, ... , ADMIN: true/false } สำหรับ role หนึ่งๆ
 * โครงสร้างนี้ต้องตรงกับที่หน้าเว็บ LIFF อ่านจาก systemData.permissions
 */
function buildPermissionsMap_(role) {
  const map = {};
  PERMISSION_KEYS.forEach(function (k) { map[k] = false; });
  map.ADMIN = role === 'ADMIN';

  if (role === 'ADMIN') {
    // isAdmin() ฝั่งหน้าเว็บ bypass ทุกอย่างอยู่แล้ว แต่ส่ง true ครบไว้เผื่อโค้ดฝั่งอื่นเช็คตรงๆ
    PERMISSION_KEYS.forEach(function (k) { map[k] = true; });
    return map;
  }

  const sh = sheet_(SHEETS.PERMISSIONS);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return map;
  const data = sh.getRange(2, 1, lastRow - 1, 3).getValues(); // role, permission_key, allowed
  data.forEach(function (r) {
    if (String(r[0]) === String(role) && String(r[2]).toUpperCase() === 'Y') {
      map[String(r[1])] = true;
    }
  });
  return map;
}

/** โยน Error ถ้าผู้ใช้ไม่มีสิทธิ์ตาม permission key — ใช้คลุมต้น action ที่ต้องจำกัดสิทธิ์ */
function requirePermission_(lineUserId, permissionKey) {
  const user = getUserByLineId_(lineUserId);
  if (!user) throw new Error('ไม่พบผู้ใช้นี้ในระบบ กรุณาลงทะเบียนก่อน');
  if (user.status !== 'ACTIVE') throw new Error('บัญชีผู้ใช้นี้ถูกระงับการใช้งาน');
  if (user.role === 'ADMIN') return user; // แอดมินผ่านทุกอย่าง
  const map = buildPermissionsMap_(user.role);
  if (!map[permissionKey]) {
    throw new Error('สิทธิ์ (' + user.role + ') ไม่สามารถทำรายการนี้ได้ (' + permissionKey + ')');
  }
  return user;
}
