/**
 * Staff.gs
 * action: updateStaff — ตรงกับ editStaff()/saveStaff() ในหน้าเว็บ (แก้ชื่อ/role/status ของพนักงานคนอื่น)
 */

function listStaff_() {
  const sh = sheet_(SHEETS.USERS);
  const lastRow = sh.getLastRow();
  if (lastRow < 2) return [];
  const data = sh.getRange(2, 1, lastRow - 1, 8).getValues();
  return data
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      const o = {};
      Object.keys(COLS.USERS).forEach(function (key) { o[key] = r[COLS.USERS[key] - 1]; });
      return o;
    });
}

/** action: updateStaff — ต้องมีสิทธิ์ VIEW_STAFF (แถบ Staff Management ในเว็บก็ gate ด้วยตัวเดียวกัน) */
function updateStaff_(lineUserId, targetLineUserId, fields) {
  requirePermission_(lineUserId, 'VIEW_STAFF');
  const row = findRowByValue_(SHEETS.USERS, COLS.USERS.line_user_id, targetLineUserId);
  if (row === -1) throw new Error('ไม่พบพนักงานคนนี้ในระบบ');
  if (fields.role && ROLES.indexOf(fields.role) === -1) {
    throw new Error('role ไม่ถูกต้อง: ' + fields.role + ' (ต้องเป็นหนึ่งใน ' + ROLES.join(', ') + ')');
  }
  updateRowFields_(SHEETS.USERS, row, COLS.USERS, {
    full_name: fields.full_name,
    role: fields.role,
    status: fields.status,
    updated_at: nowTs_(),
  });
}
