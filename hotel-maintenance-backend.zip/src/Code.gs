/**
 * Code.gs
 * จุดเข้าหลักของ Web App — รับ POST จากหน้าเว็บ LIFF (fetch กับ Content-Type: text/plain
 * เพื่อเลี่ยง CORS preflight — ดังนั้น doPost ต้อง JSON.parse เอง ไม่พึ่ง e.parameter)
 *
 * รูปแบบ request/response: { action: string, data: object } -> JSON ตรงกับที่แต่ละหน้าจอในเว็บคาดหวัง
 *
 * วิธี deploy:
 *   1. Deploy > New deployment > Type: Web app
 *   2. Execute as: Me , Who has access: Anyone (หรือ Anyone with Google account ตามนโยบายองค์กร)
 *   3. คัดลอก URL ที่ได้ไปแทนที่ API_URL ในไฟล์ index.html ของหน้าเว็บ LIFF
 */

function doPost(e) {
  let action = '';
  try {
    const body = JSON.parse(e.postData.contents);
    action = body.action;
    const data = body.data || {};
    const result = routeAction_(action, data);
    return jsonOut_(result);
  } catch (err) {
    Logger.log('doPost error [' + action + ']: ' + err + '\n' + err.stack);
    return jsonOut_({ status: 'error', message: err.message || String(err) });
  }
}

function doGet(e) {
  return ContentService.createTextOutput('Hotel Maintenance API is running.');
}

function jsonOut_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function routeAction_(action, data) {
  switch (action) {
    case 'getUser':               return apiGetUser_(data);
    case 'registerUser':          return apiRegisterUser_(data);
    case 'getInitialData':        return apiGetInitialData_(data);
    case 'createTicket':          return apiCreateTicket_(data);
    case 'updateTicketStatus':    return apiUpdateTicketStatus_(data);
    case 'closeTicket':           return apiCloseTicket_(data);
    case 'reopenTicket':          return apiReopenTicket_(data);
    case 'createPendingPartsPDF': return apiCreatePendingPartsPdf_(data);
    case 'stockIn':               return apiStockIn_(data);
    case 'stockOut':              return apiStockOut_(data);
    case 'updateStaff':           return apiUpdateStaff_(data);
    case 'updateSetting':         return apiUpdateSetting_(data);
    default:
      return { status: 'error', message: 'ไม่รู้จัก action: ' + action };
  }
}

// ---- แต่ละ action ----

function apiGetUser_(data) {
  const user = getUserByLineId_(data.userId);
  if (!user) return { status: 'NOT_REGISTERED' };
  if (user.status !== 'ACTIVE') return { status: 'error', message: 'บัญชีผู้ใช้นี้ถูกระงับการใช้งาน' };
  return {
    status: 'APPROVED',
    data: { full_name: user.full_name, department: user.department, role: user.role, emp_id: user.emp_id },
  };
}

function apiRegisterUser_(data) {
  if (!data.line_user_id || !data.emp_id || !data.full_name || !data.department) {
    throw new Error('ข้อมูลลงทะเบียนไม่ครบ');
  }
  registerUser_(data.line_user_id, data.emp_id, data.full_name, data.department);
  return { status: 'success' };
}

function apiGetInitialData_(data) {
  const user = getUserByLineId_(data.userId);
  if (!user) return { status: 'error', message: 'ไม่พบผู้ใช้นี้ในระบบ' };

  const permissions = buildPermissionsMap_(user.role);
  const ticketsInfo = listTicketsWithSummary_();

  const result = {
    status: 'success',
    user: { full_name: user.full_name, department: user.department, role: user.role },
    permissions: permissions,
    tickets: ticketsInfo.tickets,
    summary: ticketsInfo.summary,
    inventory: [],
    staff: [],
    requisitions: [],
    settings: {},
  };

  if (permissions.VIEW_STOCK) result.inventory = listInventory_();
  if (permissions.VIEW_STAFF) result.staff = listStaff_();
  if (permissions.VIEW_REQUISITIONS) result.requisitions = listRequisitions_();
  if (permissions.VIEW_SETTINGS) result.settings = getAllAppSettings_();

  return result;
}

function apiCreateTicket_(data) {
  const ticketNo = createTicket_(data.line_user_id, data);
  return { status: 'success', ticketNo: ticketNo };
}

function apiUpdateTicketStatus_(data) {
  updateTicketStatus_(data.line_user_id, data.ticketNo, data.status, data.note);

  // เปลี่ยนเป็น "รออะไหล่" ครั้งแรก -> สร้าง Requisition ว่างไว้อัตโนมัติให้คลัง/หัวหน้างานมาเติมรายการอะไหล่ต่อ
  if (data.status === TICKET_STATUS.PENDING_PARTS && !findRequisitionForTicket_(data.ticketNo)) {
    createRequisitionForTicket_(data.line_user_id, data.ticketNo, [], data.note || '');
  }
  return { status: 'success' };
}

function apiCloseTicket_(data) {
  closeTicket_(data.line_user_id, data.ticketNo, data.notes);
  return { status: 'success' };
}

function apiReopenTicket_(data) {
  reopenTicket_(data.line_user_id, data.ticketNo);
  return { status: 'success' };
}

function apiCreatePendingPartsPdf_(data) {
  const pdfUrl = createPendingPartsPdf_(data.line_user_id, data.ticketNo);
  return { status: 'success', pdfUrl: pdfUrl };
}

function apiStockIn_(data) {
  stockIn_(data.line_user_id, data.item_code, Number(data.quantity), data.note);
  return { status: 'success' };
}

function apiStockOut_(data) {
  stockOut_(data.line_user_id, data.item_code, Number(data.quantity), data.note);
  return { status: 'success' };
}

function apiUpdateStaff_(data) {
  updateStaff_(data.line_user_id, data.target_line_user_id, {
    full_name: data.full_name, role: data.role, status: data.status,
  });
  return { status: 'success' };
}

function apiUpdateSetting_(data) {
  updateAppSetting_(data.line_user_id, data.key, data.value);
  return { status: 'success' };
}
