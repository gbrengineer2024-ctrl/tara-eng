/**
 * Config.gs
 * ค่าคงที่ทั้งหมด — อ้างอิงตาม "หน้าเว็บ LIFF" ที่เป็นระบบจริง (ไม่ใช่สคีมาที่ตั้งไว้ตอนแรก)
 * ห้ามแก้ชื่อ field / permission key เองโดยไม่แก้โค้ดฝั่งหน้าเว็บพร้อมกัน เพราะ 2 ฝั่งผูกกันด้วยชื่อ field ตรงตัว
 *
 * Script Properties ที่ต้องตั้งก่อนใช้งาน (Project Settings > Script Properties):
 *   PDF_OUTPUT_FOLDER_ID = Google Drive Folder ID สำหรับเก็บไฟล์ PDF ที่ export
 * (ระบบนี้ไม่ได้คุยกับ LINE Messaging API โดยตรง — หน้าเว็บ LIFF เป็นคนคุยกับผู้ใช้ทั้งหมด
 *  แล้วเรียก Web App นี้ผ่าน fetch POST เท่านั้น จึงไม่ต้องใช้ LINE_CHANNEL_ACCESS_TOKEN ในสคริปต์นี้)
 */

const SHEETS = {
  INVENTORY: 'Inventory',
  TICKETS: 'Tickets',
  TICKET_MATERIALS: 'Ticket_Materials',
  STOCK_MOVEMENTS: 'Stock_Movements',
  REQUISITIONS: 'Requisitions',
  REQUISITION_ITEMS: 'Requisition_Items',
  TICKET_PRINT: 'Ticket_Print',
  USERS: 'Users',
  PERMISSIONS: 'Permissions',
  APP_SETTINGS: 'AppSettings',
  SETTINGS: 'Settings',
};

// ต้องตรงกับ Hotel_Maintenance_System_v4.xlsx เป๊ะๆ (แก้ที่นี่ที่เดียวถ้าแก้โครงสร้างชีต)
const COLS = {
  INVENTORY: {
    item_code: 1, item_name: 2, category: 3, unit: 4, quantity: 5, min_stock: 6, status: 7,
    supplier_code: 8, unit_cost: 9, storage_location: 10, updated_at: 11, updated_by: 12,
  },

  TICKETS: {
    ticket_no: 1, location: 2, category: 3, priority: 4, issue: 5, status: 6, reporter: 7,
    technician: 8, department: 9, created_at: 10, updated_at: 11, completed_at: 12,
    work_note: 13, pdf_url: 14, reporter_line_id: 15, technician_line_id: 16, image_urls: 17,
  },

  TICKET_MATERIALS: {
    ticket_no: 1, item_code: 2, quantity_used: 3, unit_cost: 4, total_cost: 5, used_by: 6, used_at: 7,
  },

  STOCK_MOVEMENTS: {
    movement_id: 1, movement_date: 2, item_code: 3, item_name: 4, movement_type: 5,
    quantity: 6, ref_type: 7, ref_no: 8, note: 9, performed_by: 10, balance_after: 11,
  },

  REQUISITIONS: {
    requisition_no: 1, ticket_no: 2, location: 3, department: 4, submitted_by: 5, status: 6,
    approved_by: 7, approved_at: 8, total_amount: 9, note: 10, pdf_url: 11, created_at: 12,
  },

  REQUISITION_ITEMS: {
    requisition_no: 1, item_code: 2, item_name: 3, unit: 4, quantity_requested: 5,
    unit_price: 6, amount: 7, received_qty: 8, line_no: 9, pr_line_key: 10,
  },

  USERS: {
    line_user_id: 1, emp_id: 2, full_name: 3, department: 4, role: 5,
    registered_at: 6, status: 7, updated_at: 8,
  },

  PERMISSIONS: { role: 1, permission_key: 2, allowed: 3 },

  APP_SETTINGS: { key: 1, value: 2, updated_by: 3, updated_at: 4 },
};

// ต้องตรงกับ dropdown/logic ในหน้าเว็บ LIFF ทุกตัวอักษร
const TICKET_STATUS = {
  NEW: 'NEW',
  IN_PROGRESS: 'IN_PROGRESS',
  ON_HOLD: 'ON_HOLD',
  PENDING_PARTS: 'PENDING_PARTS',
  COMPLETED: 'COMPLETED',
  REOPENED: 'REOPENED',
  CANCELLED: 'CANCELLED',
};

const ROLES = ['ADMIN', 'SUPERVISOR', 'TECHNICIAN', 'REPORTER'];
const DEFAULT_ROLE = 'REPORTER'; // role เริ่มต้นตอนลงทะเบียนใหม่จากหน้าเว็บ

// permission key ต้องตรงกับที่ hasPermission('...') เรียกในโค้ดหน้าเว็บ LIFF เป๊ะๆ
const PERMISSION_KEYS = [
  'CHANGE_STATUS', 'CLOSE_TICKET', 'REOPEN_TICKET', 'PRINT_PENDING_PARTS_PDF',
  'VIEW_STAFF', 'VIEW_STOCK', 'VIEW_REQUISITIONS', 'VIEW_SETTINGS',
];

const MOVEMENT_TYPE = { STOCK_IN: 'STOCK_IN', STOCK_OUT: 'STOCK_OUT', ADJUST_IN: 'ADJUST_IN', ADJUST_OUT: 'ADJUST_OUT' };

function getProp_(key) {
  const v = PropertiesService.getScriptProperties().getProperty(key);
  if (!v) throw new Error('ยังไม่ได้ตั้งค่า Script Property: ' + key);
  return v;
}

function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }

function sheet_(name) {
  const sh = ss_().getSheetByName(name);
  if (!sh) throw new Error('ไม่พบชีต: ' + name);
  return sh;
}
