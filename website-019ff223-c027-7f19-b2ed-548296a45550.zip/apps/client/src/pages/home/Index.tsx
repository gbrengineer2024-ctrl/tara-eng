import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  Bell,
  Boxes,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  Clock3,
  FileText,
  Gauge,
  Hotel,
  LayoutDashboard,
  LogOut,
  Menu,
  MoreHorizontal,
  Package,
  Plus,
  RefreshCw,
  Search,
  Settings,
  ShieldCheck,
  UserRound,
  Users,
  Wrench,
  X,
} from "lucide-react";
import { toast } from "sonner";

type WorkStatus = "กำลังดำเนินการ" | "รออะไหล่" | "เสร็จแล้ว";
type WorkFilter = "ทั้งหมด" | WorkStatus;

type WorkOrder = {
  id: string;
  title: string;
  location: string;
  reporter: string;
  time: string;
  status: WorkStatus;
  priority: "ด่วน" | "ปกติ";
};

const workOrders: WorkOrder[] = [
  {
    id: "WO-0268",
    title: "เครื่องปรับอากาศไม่เย็น",
    location: "ห้องพัก 1208 · ชั้น 12",
    reporter: "แผนกแม่บ้าน",
    time: "09:42",
    status: "กำลังดำเนินการ",
    priority: "ด่วน",
  },
  {
    id: "WO-0267",
    title: "เปลี่ยนหลอดไฟโถงทางเดิน",
    location: "อาคาร B · ชั้น 4",
    reporter: "Front Office",
    time: "08:15",
    status: "รออะไหล่",
    priority: "ปกติ",
  },
  {
    id: "WO-0266",
    title: "ตรวจเช็กปั๊มน้ำประจำวัน",
    location: "ห้องเครื่อง · ชั้นใต้ดิน",
    reporter: "Engineering",
    time: "07:30",
    status: "เสร็จแล้ว",
    priority: "ปกติ",
  },
  {
    id: "WO-0265",
    title: "ซ่อมบานพับประตูห้องประชุม",
    location: "ห้องประชุม Tara 2",
    reporter: "ฝ่ายจัดเลี้ยง",
    time: "เมื่อวาน",
    status: "เสร็จแล้ว",
    priority: "ปกติ",
  },
];

const filterCounts: Record<WorkFilter, number> = {
  ทั้งหมด: 5,
  กำลังดำเนินการ: 1,
  รออะไหล่: 1,
  เสร็จแล้ว: 3,
};

const statusStyle: Record<
  WorkStatus,
  { dot: string; badge: string; icon: typeof Clock3 }
> = {
  กำลังดำเนินการ: {
    dot: "bg-sky-400",
    badge: "border-sky-400/20 bg-sky-400/10 text-sky-200",
    icon: Clock3,
  },
  รออะไหล่: {
    dot: "bg-amber-400",
    badge: "border-amber-400/20 bg-amber-400/10 text-amber-200",
    icon: Package,
  },
  เสร็จแล้ว: {
    dot: "bg-emerald-400",
    badge: "border-emerald-400/20 bg-emerald-400/10 text-emerald-200",
    icon: CheckCircle2,
  },
};

const navigation = [
  { label: "ภาพรวม", icon: LayoutDashboard, active: true },
  { label: "งานซ่อม", icon: Wrench, active: false },
  { label: "แผนบำรุงรักษา", icon: CalendarClock, active: false },
  { label: "คลังอะไหล่", icon: Boxes, active: false },
  { label: "รายงาน", icon: FileText, active: false },
];

const adminActions = [
  {
    title: "คลังอะไหล่",
    subtitle: "รับเข้า · เบิกจ่าย · ตรวจนับ",
    icon: Boxes,
    color: "from-cyan-400/20 to-blue-500/5 text-cyan-200",
  },
  {
    title: "รายการรออะไหล่",
    subtitle: "ใบเบิกและเอกสาร PDF",
    icon: ClipboardList,
    color: "from-amber-400/20 to-orange-500/5 text-amber-200",
  },
  {
    title: "จัดการพนักงาน",
    subtitle: "ทีมงานและตารางปฏิบัติงาน",
    icon: Users,
    color: "from-emerald-400/20 to-teal-500/5 text-emerald-200",
  },
  {
    title: "ตั้งค่าระบบ",
    subtitle: "แผนก · สิทธิ์ · การแจ้งเตือน",
    icon: Settings,
    color: "from-violet-400/20 to-purple-500/5 text-violet-200",
  },
];

function AppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="grid size-10 shrink-0 place-items-center rounded-2xl border border-cyan-300/20 bg-cyan-300/10 text-cyan-200 shadow-[0_12px_30px_rgba(16,185,240,0.12)]">
        <Hotel className="size-5" strokeWidth={2.2} />
      </div>
      {!compact && (
        <div>
          <p className="font-semibold tracking-[-0.02em] text-white">Tara Engineering</p>
          <p className="text-xs text-slate-400">Hotel Maintenance</p>
        </div>
      )}
    </div>
  );
}

function Sidebar({
  mobile = false,
  onClose,
}: {
  mobile?: boolean;
  onClose?: () => void;
}) {
  const notify = (label: string) => {
    toast.info(`เปิดเมนู “${label}”`, {
      description: "หน้านี้เป็นตัวอย่างการออกแบบส่วนติดต่อผู้ใช้",
    });
    onClose?.();
  };

  return (
    <aside
      className={
        mobile
          ? "flex h-full w-[286px] flex-col border-r border-white/8 bg-[#081526] px-5 py-6 shadow-2xl"
          : "sticky top-0 hidden h-screen w-[260px] shrink-0 flex-col border-r border-white/8 bg-[#081526]/95 px-5 py-6 backdrop-blur-xl lg:flex"
      }
    >
      <div className="flex items-center justify-between px-2">
        <AppLogo />
        {mobile && (
          <button
            type="button"
            aria-label="ปิดเมนู"
            onClick={onClose}
            className="grid size-9 place-items-center rounded-xl text-slate-400 transition hover:bg-white/6 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
          >
            <X className="size-5" />
          </button>
        )}
      </div>

      <nav className="mt-10 space-y-1.5" aria-label="เมนูหลัก">
        <p className="mb-3 px-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">
          Workspace
        </p>
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              type="button"
              onClick={() => notify(item.label)}
              className={`group flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left text-sm font-medium transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 ${
                item.active
                  ? "bg-cyan-300/10 text-cyan-100 shadow-[inset_0_0_0_1px_rgba(103,232,249,0.10)]"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-100"
              }`}
            >
              <Icon className={`size-[18px] ${item.active ? "text-cyan-300" : "text-slate-500 group-hover:text-slate-300"}`} />
              <span className="flex-1">{item.label}</span>
              {item.active && <span className="size-1.5 rounded-full bg-cyan-300 shadow-[0_0_12px_rgba(103,232,249,0.7)]" />}
            </button>
          );
        })}
      </nav>

      <div className="mt-auto rounded-3xl border border-white/8 bg-white/[0.035] p-4">
        <div className="flex items-center gap-3">
          <div className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-cyan-300 to-blue-500 font-bold text-[#06111f]">
            B
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-white">Bom</p>
            <p className="truncate text-xs text-slate-400">Engineering Supervisor</p>
          </div>
          <button
            type="button"
            aria-label="ออกจากระบบ"
            onClick={() => toast.info("ออกจากระบบ", { description: "ตัวอย่างปุ่มสำหรับเชื่อมต่อระบบยืนยันตัวตน" })}
            className="grid size-9 place-items-center rounded-xl text-slate-500 transition hover:bg-white/6 hover:text-rose-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
          >
            <LogOut className="size-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}

function StatCard({
  label,
  value,
  detail,
  icon: Icon,
  accent,
  selected,
  onClick,
}: {
  label: WorkFilter;
  value: number;
  detail: string;
  icon: typeof Clock3;
  accent: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={selected}
      className={`group relative overflow-hidden rounded-3xl border p-5 text-left transition duration-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 ${
        selected
          ? "border-cyan-300/30 bg-cyan-300/[0.08] shadow-[0_18px_50px_rgba(3,13,27,0.22)]"
          : "border-white/8 bg-white/[0.035] hover:-translate-y-0.5 hover:border-white/15 hover:bg-white/[0.055]"
      }`}
    >
      <div className={`absolute -right-10 -top-12 size-32 rounded-full blur-3xl opacity-35 ${accent}`} />
      <div className="relative flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-slate-400">{label}</p>
          <p className="mt-3 text-3xl font-bold tracking-[-0.04em] text-white">{value}</p>
          <p className="mt-1 text-xs text-slate-500">{detail}</p>
        </div>
        <div className={`grid size-11 place-items-center rounded-2xl border border-white/8 bg-white/5 ${accent}`}>
          <Icon className="size-5" strokeWidth={2.1} />
        </div>
      </div>
    </button>
  );
}

function Index() {
  const [filter, setFilter] = useState<WorkFilter>("ทั้งหมด");
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (refreshTimer.current) {
        clearTimeout(refreshTimer.current);
      }
    };
  }, []);

  const visibleOrders =
    filter === "ทั้งหมด"
      ? workOrders
      : workOrders.filter((order) => order.status === filter);

  const handleRefresh = () => {
    setIsRefreshing(true);
    if (refreshTimer.current) {
      clearTimeout(refreshTimer.current);
    }
    refreshTimer.current = setTimeout(() => {
      setIsRefreshing(false);
      toast.success("อัปเดตข้อมูลเรียบร้อย", {
        description: "ข้อมูลใบงานและคลังอะไหล่เป็นข้อมูลล่าสุดแล้ว",
      });
    }, 850);
  };

  const openAction = (title: string) => {
    toast.info(title, {
      description: "พร้อมเชื่อมต่อกับหน้าทำงานจริงในขั้นตอนถัดไป",
    });
  };

  return (
    <div className="min-h-screen bg-[#06111f] text-slate-100 selection:bg-cyan-300/25">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-32 size-[420px] rounded-full bg-blue-500/[0.08] blur-[110px]" />
        <div className="absolute right-[-8rem] top-[28rem] size-[380px] rounded-full bg-cyan-400/[0.055] blur-[120px]" />
      </div>

      <div className="relative flex min-h-screen">
        <Sidebar />

        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <button
              type="button"
              aria-label="ปิดเมนู"
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="relative h-full animate-[slide-in_.24s_ease-out]">
              <Sidebar mobile onClose={() => setMobileMenuOpen(false)} />
            </div>
          </div>
        )}

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-30 border-b border-white/7 bg-[#06111f]/82 backdrop-blur-xl">
            <div className="mx-auto flex h-[72px] max-w-[1500px] items-center gap-3 px-4 sm:px-6 xl:px-9">
              <button
                type="button"
                aria-label="เปิดเมนู"
                onClick={() => setMobileMenuOpen(true)}
                className="grid size-10 place-items-center rounded-2xl border border-white/8 bg-white/4 text-slate-300 transition hover:bg-white/7 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 lg:hidden"
              >
                <Menu className="size-5" />
              </button>
              <div className="lg:hidden">
                <AppLogo compact />
              </div>

              <div className="hidden flex-1 items-center md:flex">
                <div className="relative w-full max-w-[390px]">
                  <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
                  <input
                    type="search"
                    aria-label="ค้นหาใบงาน"
                    placeholder="ค้นหาเลขที่ใบงาน ห้อง หรืออุปกรณ์..."
                    className="h-11 w-full rounded-2xl border border-white/8 bg-white/[0.035] pl-11 pr-4 text-sm text-slate-200 outline-none transition placeholder:text-slate-600 hover:border-white/12 focus:border-cyan-300/30 focus:bg-white/[0.05] focus:ring-4 focus:ring-cyan-300/5"
                  />
                </div>
              </div>

              <div className="ml-auto flex items-center gap-2">
                <button
                  type="button"
                  aria-label="การแจ้งเตือน"
                  onClick={() => toast.info("ไม่มีการแจ้งเตือนใหม่")}
                  className="relative grid size-10 place-items-center rounded-2xl border border-white/8 bg-white/[0.035] text-slate-400 transition hover:border-white/15 hover:bg-white/6 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                >
                  <Bell className="size-[18px]" />
                  <span className="absolute right-2.5 top-2.5 size-1.5 rounded-full bg-rose-400 ring-2 ring-[#0a1728]" />
                </button>
                <button
                  type="button"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  aria-label="อัปเดตข้อมูล"
                  className="flex h-10 items-center gap-2 rounded-2xl border border-white/8 bg-white/[0.035] px-3 text-xs font-medium text-slate-300 transition hover:border-white/15 hover:bg-white/6 hover:text-white disabled:cursor-wait disabled:opacity-60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 sm:px-4"
                >
                  <RefreshCw className={`size-4 ${isRefreshing ? "animate-spin" : ""}`} />
                  <span className="hidden sm:inline">{isRefreshing ? "กำลังอัปเดต" : "อัปเดต"}</span>
                </button>
              </div>
            </div>
          </header>

          <div className="mx-auto max-w-[1500px] px-4 pb-14 pt-7 sm:px-6 sm:pt-9 xl:px-9">
            <section className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <div className="mb-3 flex items-center gap-2 text-xs font-medium text-cyan-200/80">
                  <span className="size-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]" />
                  ระบบพร้อมใช้งาน
                  <span className="text-slate-600">·</span>
                  <span className="text-slate-500">วันอังคารที่ 11 สิงหาคม 2569</span>
                </div>
                <h1 className="text-2xl font-bold tracking-[-0.035em] text-white sm:text-3xl">
                  สวัสดีครับ, Bom
                </h1>
                <p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">
                  ภาพรวมงานซ่อมและการบำรุงรักษาประจำวันของโรงแรม
                </p>
              </div>
              <button
                type="button"
                onClick={() => openAction("สร้างใบแจ้งซ่อมใหม่")}
                className="group inline-flex h-11 items-center justify-center gap-2 self-start rounded-2xl bg-cyan-300 px-5 text-sm font-bold text-[#06111f] shadow-[0_12px_35px_rgba(103,232,249,0.16)] transition hover:-translate-y-0.5 hover:bg-cyan-200 hover:shadow-[0_18px_45px_rgba(103,232,249,0.22)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-100 active:translate-y-0 sm:self-auto"
              >
                <Plus className="size-4 transition group-hover:rotate-90" strokeWidth={2.6} />
                แจ้งซ่อมใหม่
              </button>
            </section>

            <section className="mt-7 grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4" aria-label="สรุปสถานะใบงาน">
              <StatCard
                label="ทั้งหมด"
                value={5}
                detail="ใบงานเดือนนี้ 42 รายการ"
                icon={ClipboardList}
                accent="bg-cyan-300 text-cyan-200"
                selected={filter === "ทั้งหมด"}
                onClick={() => setFilter("ทั้งหมด")}
              />
              <StatCard
                label="กำลังดำเนินการ"
                value={1}
                detail="อยู่ใน SLA"
                icon={Wrench}
                accent="bg-sky-400 text-sky-200"
                selected={filter === "กำลังดำเนินการ"}
                onClick={() => setFilter("กำลังดำเนินการ")}
              />
              <StatCard
                label="รออะไหล่"
                value={1}
                detail="คาดว่าจะได้รับวันนี้"
                icon={Package}
                accent="bg-amber-400 text-amber-200"
                selected={filter === "รออะไหล่"}
                onClick={() => setFilter("รออะไหล่")}
              />
              <StatCard
                label="เสร็จแล้ว"
                value={3}
                detail="อัตราสำเร็จ 94%"
                icon={CheckCircle2}
                accent="bg-emerald-400 text-emerald-200"
                selected={filter === "เสร็จแล้ว"}
                onClick={() => setFilter("เสร็จแล้ว")}
              />
            </section>

            <div className="mt-6 grid gap-6 xl:grid-cols-[minmax(0,1.65fr)_minmax(330px,.75fr)]">
              <div className="min-w-0 space-y-6">
                <section className="rounded-[28px] border border-white/8 bg-white/[0.032] p-4 shadow-[0_24px_80px_rgba(0,0,0,0.12)] sm:p-6">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2.5">
                        <div className="grid size-9 place-items-center rounded-xl bg-cyan-300/10 text-cyan-200">
                          <Wrench className="size-[18px]" />
                        </div>
                        <h2 className="text-lg font-bold tracking-[-0.02em] text-white">Engineering Work Order</h2>
                      </div>
                      <p className="mt-2 pl-[46px] text-xs text-slate-500">เครื่องมือหลักสำหรับทีมช่าง</p>
                    </div>
                    <ShieldCheck className="hidden size-5 text-emerald-300/70 sm:block" />
                  </div>

                  <div className="mt-5 grid gap-3 md:grid-cols-2">
                    <button
                      type="button"
                      onClick={() => openAction("แจ้งซ่อม")}
                      className="group relative min-h-[156px] overflow-hidden rounded-3xl border border-cyan-300/15 bg-gradient-to-br from-cyan-300/[0.12] via-blue-400/[0.055] to-transparent p-5 text-left transition duration-300 hover:-translate-y-1 hover:border-cyan-300/30 hover:bg-cyan-300/[0.09] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                    >
                      <div className="absolute -bottom-12 -right-8 size-40 rounded-full bg-cyan-300/10 blur-3xl transition group-hover:bg-cyan-300/20" />
                      <div className="relative flex h-full flex-col justify-between gap-6">
                        <div className="flex items-start justify-between">
                          <div className="grid size-12 place-items-center rounded-2xl border border-cyan-300/20 bg-cyan-300/10 text-cyan-200">
                            <AlertTriangle className="size-6" />
                          </div>
                          <ArrowUpRight className="size-5 text-cyan-200/50 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-cyan-200" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">แจ้งซ่อม</h3>
                          <p className="mt-1 text-sm text-slate-400">สร้างใบงานใหม่พร้อมระบุพื้นที่และความเร่งด่วน</p>
                        </div>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => openAction("งานซ่อม")}
                      className="group min-h-[156px] rounded-3xl border border-white/8 bg-white/[0.035] p-5 text-left transition duration-300 hover:-translate-y-1 hover:border-white/15 hover:bg-white/[0.06] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                    >
                      <div className="flex h-full flex-col justify-between gap-6">
                        <div className="flex items-start justify-between">
                          <div className="grid size-12 place-items-center rounded-2xl border border-white/10 bg-white/6 text-slate-200">
                            <Wrench className="size-6" />
                          </div>
                          <ChevronRight className="size-5 text-slate-600 transition group-hover:translate-x-1 group-hover:text-slate-300" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white">งานซ่อมของฉัน</h3>
                          <p className="mt-1 text-sm text-slate-400">ติดตาม อัปเดต และปิดใบงานที่ได้รับมอบหมาย</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </section>

                <section className="overflow-hidden rounded-[28px] border border-white/8 bg-white/[0.032] shadow-[0_24px_80px_rgba(0,0,0,0.12)]">
                  <div className="flex flex-col gap-4 border-b border-white/7 px-4 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                    <div>
                      <h2 className="flex items-center gap-2 text-lg font-bold tracking-[-0.02em] text-white">
                        <ClipboardList className="size-5 text-cyan-200" />
                        รายการล่าสุด
                      </h2>
                      <p className="mt-1 text-xs text-slate-500">
                        แสดง {visibleOrders.length} จาก {filterCounts[filter]} รายการในสถานะนี้
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {(["ทั้งหมด", "กำลังดำเนินการ", "รออะไหล่", "เสร็จแล้ว"] as WorkFilter[]).map((item) => (
                        <button
                          key={item}
                          type="button"
                          onClick={() => setFilter(item)}
                          className={`rounded-xl px-3 py-2 text-xs font-medium transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300 ${
                            filter === item
                              ? "bg-cyan-300 text-[#06111f]"
                              : "bg-white/[0.045] text-slate-400 hover:bg-white/8 hover:text-slate-200"
                          }`}
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="divide-y divide-white/6">
                    {visibleOrders.map((order) => {
                      const currentStatus = statusStyle[order.status];
                      const StatusIcon = currentStatus.icon;
                      return (
                        <button
                          key={order.id}
                          type="button"
                          onClick={() => openAction(`${order.id} · ${order.title}`)}
                          className="group flex w-full items-center gap-3 px-4 py-4 text-left transition hover:bg-white/[0.035] focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-cyan-300 sm:gap-4 sm:px-6"
                        >
                          <div className="grid size-10 shrink-0 place-items-center rounded-2xl border border-white/8 bg-white/[0.045] text-slate-400 transition group-hover:border-cyan-300/15 group-hover:bg-cyan-300/8 group-hover:text-cyan-200 sm:size-11">
                            <StatusIcon className="size-[18px]" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                              <p className="truncate text-sm font-semibold text-slate-100">{order.title}</p>
                              {order.priority === "ด่วน" && (
                                <span className="rounded-lg bg-rose-400/10 px-2 py-0.5 text-[10px] font-bold text-rose-300 ring-1 ring-inset ring-rose-400/20">
                                  ด่วน
                                </span>
                              )}
                            </div>
                            <p className="mt-1 truncate text-xs text-slate-500">
                              {order.id} · {order.location} · {order.reporter}
                            </p>
                          </div>
                          <div className="hidden text-right sm:block">
                            <span className={`inline-flex items-center gap-1.5 rounded-xl border px-2.5 py-1 text-[11px] font-medium ${currentStatus.badge}`}>
                              <span className={`size-1.5 rounded-full ${currentStatus.dot}`} />
                              {order.status}
                            </span>
                            <p className="mt-1.5 text-[11px] text-slate-600">{order.time}</p>
                          </div>
                          <ChevronRight className="size-4 shrink-0 text-slate-700 transition group-hover:translate-x-0.5 group-hover:text-slate-400" />
                        </button>
                      );
                    })}

                    {visibleOrders.length === 0 && (
                      <div className="px-6 py-12 text-center">
                        <CheckCircle2 className="mx-auto size-8 text-emerald-300/70" />
                        <p className="mt-3 text-sm font-medium text-slate-300">ไม่มีรายการในสถานะนี้</p>
                        <p className="mt-1 text-xs text-slate-600">เลือกตัวกรองอื่นเพื่อดูใบงานเพิ่มเติม</p>
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => openAction("ดูใบงานทั้งหมด")}
                    className="flex w-full items-center justify-center gap-2 border-t border-white/7 px-5 py-4 text-xs font-semibold text-cyan-200 transition hover:bg-cyan-300/[0.045] hover:text-cyan-100 focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-cyan-300"
                  >
                    ดูใบงานทั้งหมด
                    <ArrowUpRight className="size-3.5" />
                  </button>
                </section>
              </div>

              <div className="space-y-6">
                <section className="rounded-[28px] border border-white/8 bg-white/[0.032] p-4 shadow-[0_24px_80px_rgba(0,0,0,0.12)] sm:p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-bold tracking-[-0.02em] text-white">ภาพรวมวันนี้</h2>
                      <p className="mt-1 text-xs text-slate-500">ประสิทธิภาพทีม Engineering</p>
                    </div>
                    <button
                      type="button"
                      aria-label="ตัวเลือกเพิ่มเติม"
                      onClick={() => toast.info("ตัวเลือกเพิ่มเติม")}
                      className="grid size-9 place-items-center rounded-xl text-slate-500 transition hover:bg-white/6 hover:text-slate-300 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                    >
                      <MoreHorizontal className="size-5" />
                    </button>
                  </div>

                  <div className="mt-6 flex items-center gap-5">
                    <div className="relative grid size-[112px] shrink-0 place-items-center rounded-full bg-[conic-gradient(#67e8f9_0deg,#67e8f9_338deg,rgba(255,255,255,.07)_338deg)]">
                      <div className="grid size-[88px] place-items-center rounded-full bg-[#0b192b] text-center">
                        <div>
                          <p className="text-2xl font-bold tracking-[-0.05em] text-white">94%</p>
                          <p className="text-[10px] text-slate-500">สำเร็จตาม SLA</p>
                        </div>
                      </div>
                    </div>
                    <div className="min-w-0 flex-1 space-y-3">
                      <div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">งานตามแผน</span>
                          <span className="font-semibold text-slate-200">8 / 10</span>
                        </div>
                        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/6">
                          <div className="h-full w-4/5 rounded-full bg-cyan-300" />
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">เวลาตอบรับเฉลี่ย</span>
                          <span className="font-semibold text-emerald-300">12 นาที</span>
                        </div>
                        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/6">
                          <div className="h-full w-[72%] rounded-full bg-emerald-400" />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 grid grid-cols-2 gap-3">
                    <div className="rounded-2xl border border-white/7 bg-white/[0.035] p-3.5">
                      <Gauge className="size-4 text-cyan-200" />
                      <p className="mt-3 text-lg font-bold text-white">1.8 ชม.</p>
                      <p className="mt-0.5 text-[11px] text-slate-500">เวลาซ่อมเฉลี่ย</p>
                    </div>
                    <div className="rounded-2xl border border-white/7 bg-white/[0.035] p-3.5">
                      <UserRound className="size-4 text-violet-200" />
                      <p className="mt-3 text-lg font-bold text-white">6 คน</p>
                      <p className="mt-0.5 text-[11px] text-slate-500">กำลังปฏิบัติงาน</p>
                    </div>
                  </div>
                </section>

                <section className="rounded-[28px] border border-white/8 bg-white/[0.032] p-4 shadow-[0_24px_80px_rgba(0,0,0,0.12)] sm:p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <Settings className="size-[18px] text-violet-200" />
                        <h2 className="text-lg font-bold tracking-[-0.02em] text-white">Admin Management</h2>
                      </div>
                      <p className="mt-1 text-xs text-slate-500">เมนูสำหรับบัญชีผู้ดูแลระบบ</p>
                    </div>
                    <span className="rounded-xl border border-violet-300/15 bg-violet-300/8 px-2.5 py-1 text-[10px] font-semibold text-violet-200">
                      ADMIN
                    </span>
                  </div>

                  <div className="mt-5 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2">
                    {adminActions.map((action) => {
                      const Icon = action.icon;
                      return (
                        <button
                          key={action.title}
                          type="button"
                          onClick={() => openAction(action.title)}
                          className="group rounded-2xl border border-white/7 bg-white/[0.03] p-3.5 text-left transition hover:-translate-y-0.5 hover:border-white/14 hover:bg-white/[0.055] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300"
                        >
                          <div className={`grid size-9 place-items-center rounded-xl bg-gradient-to-br ${action.color}`}>
                            <Icon className="size-[17px]" />
                          </div>
                          <p className="mt-3 text-sm font-semibold text-slate-200 transition group-hover:text-white">{action.title}</p>
                          <p className="mt-1 text-[11px] leading-4 text-slate-500">{action.subtitle}</p>
                        </button>
                      );
                    })}
                  </div>
                </section>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default Index;
